# G-Market Villa - Partner & Sell Online

![G-Market Villa Logo](www/logo.png)

A production-ready marketplace platform where partners can sell products and buyers can purchase items online. Built with modern web technologies and converted to Android using Capacitor.

## Features

### For Buyers
- Browse products by category
- Search and filter products
- Add to cart and wishlist
- Product reviews and ratings
- View partner profiles
- Secure checkout

### For Partners
- List products with photos
- Set delivery options
- Track earnings and sales
- Withdraw to bank accounts
- View order history
- Manage product inventory

### For Admins
- Platform profit tracking
- User management
- Post announcements
- Withdraw platform earnings

## Tech Stack
- HTML5, CSS3, JavaScript (ES6+)
- Capacitor for Android conversion
- LocalStorage for data persistence
- Font Awesome icons
- Google Fonts (Inter)

## Project Structure
```
gmarket-villa-app/
├── www/                    # Web assets
│   ├── index.html         # Main application
│   └── logo.png           # App icon
├── android/               # Android native project
├── capacitor.config.json  # Capacitor configuration
├── package.json           # Node.js dependencies
└── BUILD_INSTRUCTIONS.md  # Detailed build guide
```

## Quick Start

### Web Version
Simply open `www/index.html` in a modern web browser.

### Android Version
See `BUILD_INSTRUCTIONS.md` for detailed build instructions.

## Default Login Credentials

| Role   | Username         | Password  |
|--------|------------------|-----------|
| Buyer  | buyer@demo.com | pass      |
| Partner| partner@demo.com| pass     |
| Admin  | admin          | admin123  |

## Partnership Details
- **Partnership Fee:** 2.5% per sale
- **Partner Earnings:** 97.5% per sale
- **Minimum Withdrawal:** ₦500
- **Withdrawal Fee:** ₦50

## Supported Banks
- GTBank
- UBA
- Zenith Bank
- First Bank
- OPay
- Kuda
- PalmPay
- Moniepoint

## Product Categories
- Grains & Rice
- Tubers & Roots
- Proteins & Seafood
- Oils & Spices
- Provisions
- Tailoring & Fashion
- Furniture
- Electronics
- Others

## Browser Support
- Chrome (recommended)
- Firefox
- Safari
- Edge

## Mobile Support
- Android 5.0+ (via APK)
- iOS (web version)
- Responsive design for all screen sizes

## Development

### Adding New Features
1. Edit `www/index.html`
2. Test in browser
3. Run `npx cap sync android` to update Android project
4. Rebuild APK

### Customizing Theme
Edit CSS variables in `www/index.html`:
```css
:root {
    --primary: #1e5631;
    --secondary: #e67e22;
    --success: #27ae60;
    --danger: #e74c3c;
    --info: #3498db;
}
```

## Data Storage
All data is stored locally using LocalStorage:
- `gmarket_products` - Product listings
- `gmarket_users` - User accounts
- `gmarket_currentUser` - Current session
- `gmarket_cart` - Shopping cart
- `gmarket_wishlist` - Wishlist items
- `gmarket_orders` - Order history
- `gmarket_partnerOrders` - Partner orders
- `gmarket_profit` - Platform profit

## Security Notes
- This is a demo application
- Passwords are stored in plain text (for demo purposes)
- For production, implement proper backend authentication
- Use HTTPS for production deployments

## License
© 2024 G-Market Villa. All rights reserved.

## Contact
WhatsApp: +234 901 440 6974
